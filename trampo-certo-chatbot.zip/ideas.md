# Brainstorming de Design - TRAMPO CERTO Chatbot

<response>
<text>
## Ideia 1: Neo-Brutalismo Pop (O "Trampo Certo" Direto)

**Movimento de Design**: Neo-Brutalismo com toques de Pop Art.
**Princípios Chave**:
1.  **Honestidade Visual**: Elementos não tentam imitar materiais reais, mas assumem sua natureza digital com bordas e cores chapadas.
2.  **Alto Contraste**: Legibilidade máxima e impacto visual imediato.
3.  **Interatividade Tátil**: Botões com "sombras duras" que se movem fisicamente ao clique, satisfazendo o pedido de "botões 3D" de forma estilizada.

**Filosofia de Cores**:
*   Fundo: Off-white ou cinza muito claro para limpeza.
*   Primária: Azul elétrico ou Roxo vibrante para ação.
*   Acentos: Amarelo gema e Rosa choque para destaques.
*   Bordas: Preto puro (#000) com espessura de 2px a 4px.

**Paradigma de Layout**:
*   Assimétrico e modular. Caixas de conteúdo delimitadas por bordas grossas.
*   Uso de grids visíveis ou linhas de separação fortes.

**Elementos de Assinatura**:
*   **Botões 3D "Hard"**: Botões com borda preta e uma sombra sólida preta deslocada (box-shadow sem blur). Ao clicar, a sombra desaparece e o botão se desloca, simulando um pressionamento mecânico.
*   **Tipografia Bold**: Títulos grandes, quase gritando, usando fontes sem serifa robustas (ex: Archivo Black ou Syne).
*   **Ícones Outline**: Ícones com traços grossos combinando com as bordas.

**Filosofia de Interação**:
*   Tudo deve ter feedback imediato. O hover muda a cor ou a posição da sombra. O clique é "pesado" e satisfatório.

**Animação**:
*   Transições rápidas e lineares (sem curvas de aceleração suaves).
*   Elementos entram em cena deslizando de baixo com um "snap".

**Sistema Tipográfico**:
*   Títulos: **Archivo Black** ou **Clash Display** (Impacto, força).
*   Corpo: **Space Grotesk** ou **Public Sans** (Legibilidade com personalidade técnica).
</text>
<probability>0.05</probability>
</response>

<response>
<text>
## Ideia 2: Profundidade Glossy (O Futuro do Trabalho)

**Movimento de Design**: Glassmorphism evoluído com elementos 3D Renderizados.
**Princípios Chave**:
1.  **Translucidez e Luz**: Uso de camadas de vidro fosco para hierarquia.
2.  **Volume Realista**: Botões que parecem feitos de vidro, acrílico ou metal polido.
3.  **Ambiente Imersivo**: O chatbot não flutua no vazio, mas habita um espaço com luz e sombra.

**Filosofia de Cores**:
*   Fundo: Gradientes complexos e fluidos (Deep Blue, Purple, Teal) que mudam lentamente.
*   Elementos: Branco translúcido com bordas brilhantes (inner shadows).
*   Texto: Branco puro ou gradientes metálicos.

**Paradigma de Layout**:
*   Centralizado e flutuante. O chat é um "cartão" de vidro suspenso no espaço.
*   Bordas arredondadas generosas (pill shapes).

**Elementos de Assinatura**:
*   **Botões 3D "Glossy"**: Botões com gradientes, reflexos de luz (specular highlights) e sombras suaves coloridas (glow). Parecem joias ou botões de interface de nave espacial.
*   **Background Animado**: Formas abstratas 3D flutuando e girando lentamente no fundo.
*   **Blur de Fundo**: O conteúdo atrás do chat fica desfocado, focando a atenção.

**Filosofia de Interação**:
*   Suave e etérea. Hovers causam brilhos (glow) a aumentar. Cliques têm um efeito de "ripple" ou pulso de luz.

**Animação**:
*   Flutuação constante (floating) dos elementos.
*   Entradas suaves com fade e scale.

**Sistema Tipográfico**:
*   Títulos: **Outfit** ou **Plus Jakarta Sans** (Geométrico, moderno, amigável).
*   Corpo: **Inter** ou **DM Sans** (Neutro, limpo).
</text>
<probability>0.03</probability>
</response>

<response>
<text>
## Ideia 3: Claymorphism Lúdico (Trampo Certo e Leve)

**Movimento de Design**: Claymorphism (3D estilo "massinha" ou render suave).
**Princípios Chave**:
1.  **Amigabilidade Extrema**: Formas arredondadas e "fofas" que convidam ao toque.
2.  **Profundidade Suave**: Sombras internas e externas duplas para criar volume inflado.
3.  **Clareza e Otimismo**: Ambiente claro e positivo.

**Filosofia de Cores**:
*   Fundo: Tons pastéis muito claros (Azul céu, Menta, Pêssego).
*   Elementos: Branco ou cores pastéis mais saturadas.
*   Botões: Cores vibrantes mas com acabamento fosco/acetinado.

**Paradigma de Layout**:
*   Cartões flutuantes com muito arredondamento (border-radius alto).
*   Espaçamento generoso (whitespace) para "respirar".

**Elementos de Assinatura**:
*   **Botões 3D "Clay"**: Botões que parecem feitos de argila ou borracha macia. Usam `box-shadow` interno para dar volume (luz no topo, sombra embaixo) e sombra externa difusa para flutuar.
*   **Avatares 3D**: O bot pode ser uma mascote 3D renderizada simples.
*   **Container Flutuante**: A janela do chat é um bloco sólido flutuante.

**Filosofia de Interação**:
*   Elástica. Botões "afundam" suavemente ao clicar (scale down + shadow change).
*   Animações com "bounce" (efeito mola).

**Animação**:
*   Efeitos de mola (spring physics) para abrir o chat e enviar mensagens.
*   Elementos surgem com um "pop".

**Sistema Tipográfico**:
*   Títulos: **Fredoka** ou **Nunito** (Arredondado, combina com o tema soft).
*   Corpo: **Quicksand** ou **Varela Round** (Legível e amigável).
</text>
<probability>0.02</probability>
</response>
