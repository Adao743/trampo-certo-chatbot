import { createContext, useContext, useState, useEffect } from "react";

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  description: string;
  tags?: string[];
  postedAt?: string;
}

interface FavoritesContextType {
  favorites: Job[];
  addFavorite: (job: Job) => void;
  removeFavorite: (jobId: string) => void;
  isFavorited: (jobId: string) => boolean;
  clearFavorites: () => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export function FavoritesProvider({ children }: { children: React.ReactNode }) {
  const [favorites, setFavorites] = useState<Job[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Carregar favoritos do localStorage ao montar
  useEffect(() => {
    const stored = localStorage.getItem("trampo-certo-favorites");
    if (stored) {
      try {
        setFavorites(JSON.parse(stored));
      } catch (e) {
        console.error("Erro ao carregar favoritos:", e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Salvar favoritos no localStorage quando mudam
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem("trampo-certo-favorites", JSON.stringify(favorites));
    }
  }, [favorites, isLoaded]);

  const addFavorite = (job: Job) => {
    setFavorites((prev) => {
      // Evitar duplicatas
      if (prev.some((j) => j.id === job.id)) {
        return prev;
      }
      return [...prev, job];
    });
  };

  const removeFavorite = (jobId: string) => {
    setFavorites((prev) => prev.filter((j) => j.id !== jobId));
  };

  const isFavorited = (jobId: string) => {
    return favorites.some((j) => j.id === jobId);
  };

  const clearFavorites = () => {
    setFavorites([]);
  };

  return (
    <FavoritesContext.Provider
      value={{ favorites, addFavorite, removeFavorite, isFavorited, clearFavorites }}
    >
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error("useFavorites deve ser usado dentro de FavoritesProvider");
  }
  return context;
}
