import { useState } from "react";
import { X, Heart, Download, Trash2 } from "lucide-react";
import { useFavorites } from "@/contexts/FavoritesContext";
import { cn } from "@/lib/utils";

interface FavoritesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FavoritesModal({ isOpen, onClose }: FavoritesModalProps) {
  const { favorites, removeFavorite, clearFavorites } = useFavorites();
  const [selectedJob, setSelectedJob] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleExportFavorites = () => {
    const dataStr = JSON.stringify(favorites, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `trampo-certo-favoritos-${new Date().toISOString().split("T")[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-primary border-b-4 border-black p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-white fill-white" />
            <h2 className="font-display text-2xl text-white">MEUS FAVORITOS</h2>
            {favorites.length > 0 && (
              <span className="bg-secondary text-black font-bold px-3 py-1 border-2 border-black text-sm">
                {favorites.length}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-black/20 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#fdfbf7]">
          {favorites.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Heart className="w-12 h-12 text-muted mb-4 opacity-50" />
              <p className="font-bold text-lg text-black/70">Nenhuma vaga favoritada ainda</p>
              <p className="text-sm text-muted-foreground mt-1">
                Clique no coração nas vagas para salvá-las aqui
              </p>
            </div>
          ) : (
            favorites.map((job) => (
              <div
                key={job.id}
                onClick={() => setSelectedJob(selectedJob === job.id ? null : job.id)}
                className={cn(
                  "border-2 border-black p-4 cursor-pointer transition-all hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]",
                  selectedJob === job.id && "bg-secondary/20"
                )}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="font-display text-lg font-bold text-black">{job.title}</h3>
                    <p className="text-sm font-medium text-black/70 mt-1">{job.company}</p>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="text-xs bg-black text-white px-2 py-1 font-bold">
                        {job.location}
                      </span>
                      {job.salary && (
                        <span className="text-xs bg-accent text-black px-2 py-1 font-bold border border-black">
                          {job.salary}
                        </span>
                      )}
                      {job.postedAt && (
                        <span className="text-xs text-muted-foreground font-bold">
                          {job.postedAt}
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFavorite(job.id);
                    }}
                    className="p-2 hover:bg-red-100 transition-colors border-2 border-black"
                  >
                    <Trash2 className="w-5 h-5 text-red-600" />
                  </button>
                </div>

                {/* Expanded Details */}
                {selectedJob === job.id && (
                  <div className="mt-4 pt-4 border-t-2 border-black">
                    <p className="text-sm font-medium text-black/80 leading-relaxed">
                      {job.description}
                    </p>
                    {job.tags && job.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {job.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-xs bg-white border-2 border-black px-2 py-1 font-bold"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {favorites.length > 0 && (
          <div className="border-t-4 border-black bg-white p-4 flex gap-2">
            <button
              onClick={handleExportFavorites}
              className="flex-1 btn-neo bg-secondary text-black hover:bg-secondary/90 flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              EXPORTAR
            </button>
            <button
              onClick={clearFavorites}
              className="flex-1 btn-neo bg-destructive text-white hover:bg-destructive/90"
            >
              LIMPAR TUDO
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
