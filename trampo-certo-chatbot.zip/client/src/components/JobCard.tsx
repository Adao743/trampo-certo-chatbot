import { Heart, Share2 } from "lucide-react";
import { useFavorites, type Job } from "@/contexts/FavoritesContext";
import { cn } from "@/lib/utils";

interface JobCardProps {
  job: Job;
  onApply?: () => void;
  onShare?: (job: Job) => void;
}

export function JobCard({ job, onApply, onShare }: JobCardProps) {
  const { isFavorited, addFavorite, removeFavorite } = useFavorites();
  const isFav = isFavorited(job.id);

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFav) {
      removeFavorite(job.id);
    } else {
      addFavorite(job);
    }
  };

  return (
    <div className="bg-white border-2 border-black p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all">
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex-1">
          <h3 className="font-display font-bold text-lg text-black leading-tight">{job.title}</h3>
          <p className="text-sm font-medium text-black/70 mt-1">{job.company}</p>
        </div>
        <div className="flex gap-2">
          {onShare && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onShare(job);
              }}
              className="p-2 border-2 border-black bg-white text-black hover:bg-secondary transition-all hover:scale-110"
              title="Compartilhar vaga"
            >
              <Share2 className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={handleToggleFavorite}
            className={cn(
              "p-2 border-2 border-black transition-all hover:scale-110",
              isFav
                ? "bg-accent text-black fill-black"
                : "bg-white text-black hover:bg-secondary"
            )}
          >
            <Heart className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-3">
        <span className="text-xs bg-black text-white px-2 py-1 font-bold">{job.location}</span>
        {job.salary && (
          <span className="text-xs bg-secondary text-black px-2 py-1 font-bold border border-black">
            {job.salary}
          </span>
        )}
      </div>

      <p className="text-sm font-medium text-black/80 line-clamp-2 mb-3">{job.description}</p>

      {job.tags && job.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {job.tags.slice(0, 3).map((tag, idx) => (
            <span key={idx} className="text-xs bg-muted text-black px-2 py-0.5 font-bold">
              {tag}
            </span>
          ))}
          {job.tags.length > 3 && (
            <span className="text-xs text-muted-foreground px-2 py-0.5 font-bold">
              +{job.tags.length - 3}
            </span>
          )}
        </div>
      )}

      {onApply && (
        <button
          onClick={onApply}
          className="w-full btn-neo btn-neo-primary text-sm py-2"
        >
          CANDIDATAR
        </button>
      )}
    </div>
  );
}
