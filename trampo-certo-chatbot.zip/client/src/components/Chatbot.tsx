import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Briefcase, Sparkles, Heart, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFavorites, type Job } from "@/contexts/FavoritesContext";
import { JobCard } from "./JobCard";
import { FavoritesModal } from "./FavoritesModal";
import { ShareModal } from "./ShareModal";

interface Message {
  id: string;
  text?: string;
  sender: "user" | "bot";
  timestamp: Date;
  type?: "text" | "options" | "jobs";
  options?: string[];
  jobs?: Job[];
}

// Base de dados de vagas de exemplo
const SAMPLE_JOBS: Job[] = [
  {
    id: "job-1",
    title: "Desenvolvedor Full Stack React",
    company: "TechStart Brasil",
    location: "São Paulo, SP",
    salary: "R$ 8.000 - R$ 12.000",
    description: "Procuramos um desenvolvedor experiente em React e Node.js para integrar nosso time.",
    tags: ["React", "Node.js", "TypeScript", "PostgreSQL"],
    postedAt: "Há 2 dias"
  },
  {
    id: "job-2",
    title: "Especialista em UX/UI Design",
    company: "Creative Agency",
    location: "Rio de Janeiro, RJ",
    salary: "R$ 7.000 - R$ 10.000",
    description: "Buscamos um designer criativo para liderar projetos de transformação digital.",
    tags: ["Figma", "Design System", "Prototipagem"],
    postedAt: "Há 1 dia"
  },
  {
    id: "job-3",
    title: "Analista de Dados Senior",
    company: "DataCorp",
    location: "Belo Horizonte, MG",
    salary: "R$ 10.000 - R$ 15.000",
    description: "Analista com experiência em Python, SQL e BI para análise estratégica.",
    tags: ["Python", "SQL", "Power BI", "Machine Learning"],
    postedAt: "Há 3 dias"
  },
  {
    id: "job-4",
    title: "Product Manager",
    company: "Startup Inovadora",
    location: "Curitiba, PR",
    salary: "R$ 9.000 - R$ 13.000",
    description: "Procuramos PM com experiência em SaaS para liderar roadmap de produto.",
    tags: ["Agile", "Estratégia", "Liderança"],
    postedAt: "Hoje"
  },
  {
    id: "job-5",
    title: "DevOps Engineer",
    company: "CloudTech Solutions",
    location: "Brasília, DF",
    salary: "R$ 11.000 - R$ 16.000",
    description: "Profissional para gerenciar infraestrutura em cloud e CI/CD.",
    tags: ["AWS", "Docker", "Kubernetes", "Terraform"],
    postedAt: "Há 4 dias"
  },
  {
    id: "job-6",
    title: "Gerente de Vendas",
    company: "Enterprise Solutions",
    location: "Brasília, DF",
    salary: "R$ 8.500 - R$ 12.500",
    description: "Líder de vendas para expandir carteira de clientes corporativos.",
    tags: ["Vendas", "Liderança", "CRM", "Negociação"],
    postedAt: "Há 5 dias"
  }
];

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "E aí! Bem-vindo ao TRAMPO CERTO. 🚀\nTô aqui pra te ajudar a desenrolar sua carreira. O que você manda hoje?",
      sender: "bot",
      timestamp: new Date(),
      type: "options",
      options: ["Buscar Vagas", "Dicas de Currículo", "Simular Entrevista", "Sobre o Trampo Certo"]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [selectedJobForShare, setSelectedJobForShare] = useState<Job | null>(null);
  const { favorites } = useFavorites();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleShareJob = (job: Job) => {
    setSelectedJobForShare(job);
    setShowShare(true);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const newUserMessage: Message = {
      id: Date.now().toString(),
      text: text,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simular resposta do bot
    setTimeout(() => {
      const botResponse = getBotResponse(text);
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const getBotResponse = (input: string): Message => {
    const lowerInput = input.toLowerCase();
    let responseText = "Pode crer! Mas não entendi muito bem. Tenta escolher uma das opções abaixo ou pergunta de outro jeito.";
    let options: string[] | undefined = ["Buscar Vagas", "Dicas de Currículo", "Falar com Humano"];
    let jobs: Job[] | undefined;
    let type: "text" | "options" | "jobs" = "options";

    if (lowerInput.includes("vagas") || lowerInput.includes("emprego")) {
      responseText = "Boa! Tenho umas vagas quentes aqui. Qual sua área de interesse?";
      options = ["Tecnologia", "Vendas", "Administrativo", "Marketing"];
    } else if (lowerInput.includes("tecnologia")) {
      responseText = "Aqui estão as melhores vagas de Tecnologia! Clique no coração para favoritar.";
      jobs = SAMPLE_JOBS.filter(j => 
        ["React", "Node.js", "Python", "AWS", "Docker"].some(tag => 
          j.tags?.includes(tag)
        )
      );
      type = "jobs";
      options = ["Buscar Vagas", "Dicas de Currículo"];
    } else if (lowerInput.includes("vendas")) {
      responseText = "Vagas de Vendas disponíveis! Quer conhecer mais?";
      jobs = SAMPLE_JOBS.filter(j => j.tags?.includes("Vendas"));
      type = "jobs";
      options = ["Buscar Vagas", "Dicas de Currículo"];
    } else if (lowerInput.includes("currículo") || lowerInput.includes("cv")) {
      responseText = "O currículo é a chave! Quer que eu analise o seu ou quer dicas de como montar um matador?";
      options = ["Analisar meu CV", "Dicas de Formatação", "Modelos Prontos"];
    } else if (lowerInput.includes("entrevista")) {
      responseText = "Entrevista dá um frio na barriga, né? Bora treinar! Posso te fazer umas perguntas comuns.";
      options = ["Começar Simulação", "Dicas de Postura", "Perguntas Difíceis"];
    } else if (lowerInput.includes("sobre") || lowerInput.includes("trampo certo")) {
      responseText = "O TRAMPO CERTO é seu parceiro na busca pelo job dos sonhos. Usamos IA pra conectar você com as melhores oportunidades, sem enrolação.";
      options = ["Ver Vagas", "Cadastrar Currículo"];
    }

    return {
      id: (Date.now() + 1).toString(),
      text: responseText,
      sender: "bot",
      timestamp: new Date(),
      type: type,
      options: options,
      jobs: jobs
    };
  };

  return (
    <>
      <div className="w-full max-w-md mx-auto h-[600px] flex flex-col bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden relative">
        {/* Header */}
        <div className="bg-primary p-4 border-b-4 border-black flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white border-2 border-black flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <Briefcase className="w-6 h-6 text-black" />
            </div>
            <div>
              <h2 className="font-display text-xl text-white leading-none">TRAMPO CERTO</h2>
              <span className="text-xs font-bold text-black bg-secondary px-1 py-0.5 border border-black inline-block mt-1">ONLINE</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowFavorites(true)}
              className="p-2 hover:bg-black/20 transition-colors relative"
              title="Ver favoritos"
            >
              <Heart className="w-5 h-5 text-white fill-white" />
              {favorites.length > 0 && (
                <span className="absolute top-0 right-0 bg-secondary text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center border border-black">
                  {favorites.length}
                </span>
              )}
            </button>
            <a
              href="https://www.google.br"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 bg-white text-black border-2 border-white font-bold text-xs hover:bg-secondary hover:border-black transition-all shadow-[2px_2px_0px_0px_rgba(255,255,255,0.5)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px] flex items-center gap-1"
              title="Voltar para Google"
            >
              <LogOut className="w-4 h-4" />
              VOLTAR
            </a>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#fdfbf7] bg-[radial-gradient(#00000011_1px,transparent_1px)] [background-size:16px_16px]">
          {messages.map((msg) => (
            <div key={msg.id}>
              {/* Text Message */}
              {msg.type !== "jobs" && (
                <div
                  className={cn(
                    "flex flex-col max-w-[85%]",
                    msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start"
                  )}
                >
                  <div className={cn(
                    "flex items-end gap-2",
                    msg.sender === "user" ? "flex-row-reverse" : "flex-row"
                  )}>
                    <div className={cn(
                      "w-8 h-8 rounded-none border-2 border-black flex items-center justify-center shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]",
                      msg.sender === "user" ? "bg-secondary" : "bg-primary"
                    )}>
                      {msg.sender === "user" ? <User className="w-5 h-5 text-black" /> : <Bot className="w-5 h-5 text-white" />}
                    </div>
                    
                    <div className={cn(
                      "p-3 border-2 border-black text-sm font-medium shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]",
                      msg.sender === "user" 
                        ? "bg-black text-white" 
                        : "bg-white text-black"
                    )}>
                      {msg.text}
                    </div>
                  </div>

                  {/* Options Buttons */}
                  {msg.type === "options" && msg.options && (
                    <div className="mt-3 flex flex-wrap gap-2 ml-10">
                      {msg.options.map((option, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(option)}
                          className="px-3 py-1.5 text-xs font-bold bg-accent border-2 border-black hover:-translate-y-0.5 hover:translate-x-0.5 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all active:translate-x-0 active:translate-y-0 active:shadow-none"
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  )}
                  
                  <span className="text-[10px] font-bold text-muted-foreground mt-1 px-1">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              )}

              {/* Jobs List */}
              {msg.type === "jobs" && msg.jobs && (
                <div className="space-y-2 ml-auto mr-0 max-w-[95%]">
                  <div className={cn(
                    "flex items-end gap-2"
                  )}>
                    <div className="w-8 h-8 bg-primary border-2 border-black flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div className="bg-white text-black text-sm font-medium shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-3 border-2 border-black">
                      {msg.text}
                    </div>
                  </div>
                  <div className="space-y-2 ml-10">
                    {msg.jobs.map((job) => (
                      <JobCard key={job.id} job={job} onShare={handleShareJob} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
          
          {isTyping && (
            <div className="flex items-center gap-2 mr-auto">
              <div className="w-8 h-8 bg-primary border-2 border-black flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-white border-2 border-black px-4 py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex gap-1">
                <span className="w-2 h-2 bg-black animate-bounce"></span>
                <span className="w-2 h-2 bg-black animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-2 h-2 bg-black animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t-4 border-black z-10">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendMessage(inputValue)}
              placeholder="Manda o papo..."
              className="flex-1 bg-muted border-2 border-black p-3 font-medium focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent placeholder:text-gray-500"
            />
            <button
              onClick={() => handleSendMessage(inputValue)}
              disabled={!inputValue.trim()}
              className="bg-black text-white p-3 border-2 border-black hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-[2px_2px_0px_0px_rgba(100,100,100,1)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px]"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Favorites Modal */}
      <FavoritesModal isOpen={showFavorites} onClose={() => setShowFavorites(false)} />

      {/* Share Modal */}
      <ShareModal isOpen={showShare} onClose={() => setShowShare(false)} job={selectedJobForShare} />
    </>
  );
}
