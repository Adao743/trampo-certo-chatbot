import { useState } from "react";
import { X, Copy, Check, MessageCircle, Facebook, Twitter, Linkedin, Mail } from "lucide-react";
import { type Job } from "@/contexts/FavoritesContext";
import { cn } from "@/lib/utils";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: Job | null;
}

export function ShareModal({ isOpen, onClose, job }: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !job) return null;

  // Gerar URL de compartilhamento (pode ser customizada com domínio real)
  const shareUrl = `${window.location.origin}?job=${job.id}`;
  const jobText = `Vaga: ${job.title} - ${job.company} | ${job.location}`;
  const fullMessage = `${jobText}\n\n${shareUrl}`;

  const shareLinks = {
    whatsapp: `https://wa.me/?text=${encodeURIComponent(fullMessage)}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(jobText)}`,
    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Olha que vaga legal no TRAMPO CERTO: ${jobText}`)}&url=${encodeURIComponent(shareUrl)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
    email: `mailto:?subject=${encodeURIComponent(`Vaga: ${job.title}`)}&body=${encodeURIComponent(fullMessage)}`
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareOptions = [
    {
      name: "WhatsApp",
      icon: MessageCircle,
      url: shareLinks.whatsapp,
      color: "bg-[#25D366]",
      textColor: "text-white"
    },
    {
      name: "Facebook",
      icon: Facebook,
      url: shareLinks.facebook,
      color: "bg-[#1877F2]",
      textColor: "text-white"
    },
    {
      name: "Twitter",
      icon: Twitter,
      url: shareLinks.twitter,
      color: "bg-[#000000]",
      textColor: "text-white"
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      url: shareLinks.linkedin,
      color: "bg-[#0A66C2]",
      textColor: "text-white"
    },
    {
      name: "Email",
      icon: Mail,
      url: shareLinks.email,
      color: "bg-accent",
      textColor: "text-black"
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] max-w-md w-full">
        {/* Header */}
        <div className="bg-primary border-b-4 border-black p-4 flex items-center justify-between">
          <h2 className="font-display text-2xl text-white">COMPARTILHAR</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-black/20 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Job Info */}
          <div className="border-2 border-black p-4 bg-muted">
            <h3 className="font-display font-bold text-lg text-black mb-2">{job.title}</h3>
            <p className="text-sm font-medium text-black/70">{job.company}</p>
            <p className="text-xs text-muted-foreground mt-1">{job.location}</p>
          </div>

          {/* Share Options */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-black/70 uppercase">Compartilhar em:</p>
            <div className="grid grid-cols-2 gap-3">
              {shareOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <a
                    key={option.name}
                    href={option.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={cn(
                      "flex items-center justify-center gap-2 py-3 px-4 border-2 border-black font-bold text-sm transition-all hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px]",
                      option.color,
                      option.textColor
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    {option.name}
                  </a>
                );
              })}
            </div>
          </div>

          {/* Copy Link Section */}
          <div className="border-t-2 border-black pt-4">
            <p className="text-xs font-bold text-black/70 uppercase mb-3">Ou copie o link:</p>
            <div className="flex gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 bg-muted border-2 border-black p-3 text-sm font-medium focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className={cn(
                  "px-4 py-3 border-2 border-black font-bold text-sm transition-all flex items-center gap-2",
                  copied
                    ? "bg-secondary text-black"
                    : "bg-black text-white hover:bg-gray-800"
                )}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    COPIADO
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    COPIAR
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t-4 border-black bg-muted p-4">
          <button
            onClick={onClose}
            className="w-full btn-neo bg-white hover:bg-gray-50"
          >
            FECHAR
          </button>
        </div>
      </div>
    </div>
  );
}
