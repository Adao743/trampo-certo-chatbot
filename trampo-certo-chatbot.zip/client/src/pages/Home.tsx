import { Chatbot } from "@/components/Chatbot";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-secondary p-4 md:p-8 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-10 z-0">
        <div className="absolute top-10 left-10 w-32 h-32 border-4 border-black rotate-12 bg-primary"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 border-4 border-black -rotate-6 rounded-full bg-accent"></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 border-4 border-black rotate-45 bg-white"></div>
      </div>

      <main className="w-full max-w-4xl flex flex-col md:flex-row items-center gap-8 z-10">
        {/* Left Content */}
        <div className="flex-1 text-center md:text-left space-y-6">
          <div className="inline-block bg-black text-white px-4 py-1 font-bold border-2 border-white shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)] transform -rotate-2">
            BETA 2.0
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-black text-black leading-[0.9] tracking-tighter drop-shadow-sm">
            TRAMPO<br/>
            <span className="text-white text-stroke-3 text-stroke-black bg-black px-2">CERTO</span>
          </h1>
          
          <p className="text-lg md:text-xl font-medium text-black/80 max-w-md mx-auto md:mx-0 border-l-4 border-black pl-4">
            O assistente de carreira que não enrola. Vagas, dicas e simulações de entrevista direto no chat.
          </p>

          <div className="flex flex-wrap gap-4 justify-center md:justify-start pt-4">
            <button className="btn-neo btn-neo-primary">
              COMEÇAR AGORA
            </button>
            <button className="btn-neo bg-white hover:bg-gray-50">
              SAIBA MAIS
            </button>
          </div>
        </div>

        {/* Right Content - Chatbot */}
        <div className="flex-1 w-full max-w-md">
          <Chatbot />
        </div>
      </main>
      
      <footer className="absolute bottom-4 text-xs font-bold text-black/50">
        © 2026 TRAMPO CERTO INC. // FEITO COM ⚡ E ☕
      </footer>
    </div>
  );
}
